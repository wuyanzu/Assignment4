-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: localhost    Database: mydb
-- ------------------------------------------------------
-- Server version	5.6.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `2014302580311_professor_info`
--

DROP TABLE IF EXISTS `2014302580311_professor_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `2014302580311_professor_info` (
  `info1` text,
  `info2` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `2014302580311_professor_info`
--

LOCK TABLES `2014302580311_professor_info` WRITE;
/*!40000 ALTER TABLE `2014302580311_professor_info` DISABLE KEYS */;
INSERT INTO `2014302580311_professor_info` VALUES ('姓名：朱福喜',NULL),('主页：',NULL),('性别：男',NULL),('职称：教授',NULL),('学历学位：博士',NULL),('电话：',NULL),('办公地点：',NULL),('E-mail：fxzhu@public.wh.hb.cn',NULL),('硕/博士生导师：博士生导师',NULL),(NULL,'男，博士，教授，博士生导师。浙江大学数学系获学士学位、武汉大学计算机科学系获硕士学位和博士学位。一直从事人工智能和分布式计算方面的教学和科研工作。曾参与和主持了国家自然科学基金项目《专家系统开发环境与推理工具系统（87102034）》、国家863项目《国家科委办公知识信息系统（863-306-04-04-6）》和国防军工预演项目《支撑Ada语言的并行分布计算环境（15.5.1）》的开发。1993年3月赴美国加州Alpha Omega公司从事项目合作半年，2000年8月访问美国西东(Seton Hall Uni.)大学，从事远程教育和并行分布计算方面和研究一年。发表论文30余篇(其中13篇被EI检索)，编写的教材和专著共9部。参与开发的多媒体智能应用软件系统获2000年教育部科技进步二等奖，编写的教材《人工智能原理》和《Java语言与面向对象程序设计》获2002年中南地区高校优秀教材奖。'),('姓名：赵波',NULL),('主页：',NULL),('性别：男',NULL),('职称：教授',NULL),('学历学位：博士',NULL),('电话：02768775251',NULL),('办公地点：',NULL),('E-mail：zhaobo@whu.edu.cn',NULL),('硕/博士生导师：博士生导师',NULL),(NULL,'赵波，男 ，1972年12月生。1994年毕业留校至今任武汉大学计算机学院教师，教授，博士生导师。武汉大学计算机学院信息安全研究所副所长，空天信息安全与可信计算教育部重点实验室 副主任，中国计算机学会（CCF）高级会员，CCF信息保密专委委员。微软亚洲研究院技术俱乐部顾问。 目前的主要研究方向为可信计算理论、嵌入式体系结构、嵌入式软件等。主持国家863项目《可信PDA的计算平台关键技术与原型系统研究》主持国家自然科学基金、湖北省自然基金重点项目多项。国际合作、企业多项。参加国家863、国家自然科学基金、国家973等项目8项，发表论文被三大索引多篇。已获国家发明专利授权5项。'),('姓名：张健',NULL),('主页：',NULL),('性别：男',NULL),('职称：教授',NULL),('学历学位：博士',NULL),('电话：18908645188',NULL),('办公地点：',NULL),('E-mail：jzhang@whu.edu.cn sunbady@hotmail.com',NULL),('硕/博士生导师：博士生导师',NULL),(NULL,'物联网、云计算与大数据处理  '),('姓名：张沪寅',NULL),('主页：',NULL),('性别：男',NULL),('职称：教授',NULL),('学历学位：博士',NULL),('电话：',NULL),('办公地点：',NULL),('E-mail：zhy2536@whu.edu.cn',NULL),('硕/博士生导师：博士生导师',NULL),(NULL,'    武汉大学计算机学院教授，博士，博士生导师，实验教学中心主任。主持并参与了国家自然科学基金项目、电子信息产业发展基金项目、国防科技重点实验室基金项目、国家863计划引导项目、武汉市科技局科技成果推广应用计划项目、武汉市创新人才重大创新活动专项资助项目、武汉市科技攻关计划项目、武汉市软件产业发展专项资金项目、中央高校基本科研业务费专项资金资助项目的研究工作。出版10部专著和教材，发表40余篇学术论文，其中32篇被SCI/EI/ISTP三大检索收录。培养了八十余名研究生。     现为国家奖专家评审库、中国博士后科学基金评审专家库、国务院南水北调评标专家库、湖北省科技奖励评审专家库的成员。武汉大学学报、西安交大学报、浙江大学学报、电子与信息学报、计算机科学期刊、应用科学学报、小型微型计算机系统等多家国内和国外期刊论文评审专家，曾获得武汉大学教学优秀教师。'),('姓名：章登义',NULL),('主页：',NULL),('性别：男',NULL),('职称：教授',NULL),('学历学位：硕士',NULL),('电话：02768778245',NULL),('办公地点：',NULL),('E-mail：dyzhangwhu@163.com',NULL),('硕/博士生导师：博士生导师',NULL),(NULL,'1986年7月毕业于武汉测绘科技大学电子工程系，本科。 1988年12月毕业于武汉测绘科技大学计算机系，研究生。 1989年1月晋升为武汉测绘科技大学 助教。 1991年1月晋升为武汉测绘科技大学 讲师。 1994年1月破格晋升为武汉测绘科技大学 副教授。 1999年12月晋升为武汉测绘科技大学信息工程学院 教授。 2003年3月担任武汉大学计算机学院工程系 主任。 2006年1月担任武汉大学计算机学院副院长，分管科研工作。 2006年7月遴选为武汉大学博士生导师。'),('姓名：叶登攀',NULL),('主页：',NULL),('性别：男',NULL),('职称：教授',NULL),('学历学位：博士',NULL),('电话：18986213022',NULL),('办公地点：',NULL),('E-mail：yedp@whu.edu.cn yedp2001@163.com',NULL),('硕/博士生导师：硕士生导师',NULL),(NULL,'          叶登攀: 男，博士，教授，武汉大学计算机学院教师。主要学术兼职为中国人工智能学会智能数字内容安全专业委员会委员，《International Journal of Computational Intelligence Systems》客座编辑，多个重要期刊和会议审稿人。1996年毕业于华南理工大学自动化系，获工学学士学位；2001年南京理工大学自动化系直接攻读博士学位，于2005年底毕业获工学博士学位。博士学习期间从事多媒体信息处理，图像和视频水印技术，多媒体加密技术等方面的研究。2006至2007年在华中科技大学图像识别与人工智能研究所从事博士后研究，主要从事信息安全和图像处理领域研究工作。2007年12月份进入武汉大学工作，其中2011年2月至2012年2月在新加坡管理大学访问，任职Research Fellow，参与新加坡科技发展局（A*Star）项目研究。先后主持国家自然科学基金项目2项、湖北省自然基金1项、教育部实验室基金1项、中国博士后科学基金1项、武汉大学自主科研项目1项、武汉大学人参启动基金1项。在包括《通信学报》、《电子学报》、《International Journal of Computational Intelligence Systems》、《Journal of Systems Engineering and Electronics》等18篇论文上，其中被SCI收录9篇，EI收录14篇。并有多项专利授权。         欢迎同学报考，优秀学生可推荐国外访问研究和攻读博士。         办公室：武汉大学计算机学院大楼C204         联系方式：18986213022（手机）、104697503（QQ）'),('姓名：袁志勇',NULL),('主页：',NULL),('性别：男',NULL),('职称：教授',NULL),('学历学位：博士',NULL),('电话：027-68775661，13517115306',NULL),('办公地点：',NULL),('E-mail：zhiyongyuan@whu.edu.cn',NULL),('硕/博士生导师：博士生导师，硕士生导师',NULL),(NULL,'        武汉大学计算机学院教授，中国计算机学会高级会员、中国计算机学会虚拟现实与可视化技术专业委员会委员，博士生导师。在国内外期刊或国际会议发表论文100余篇，撰写出版计算机著作4部。 学习研究简历：         1986年6月：武汉大学(原武汉测绘科技大学计算机系)计算机及应用专业本科毕业         1994年6月：武汉大学(原武汉测绘科技大学电子工程系)信号与信息处理专业硕士毕业         2006年10月至2007年10月：美国匹兹堡大学医学院和该校工程学院电子与计算机工程系访问学者，从事“计算机虚拟外科手术仿真”及“医学图像分析”方面的研究工作         2008年6月：获华中科技大学控制科学与工程专业博士学位         博士研究生招生专业方向：计算机应用技术         学术型硕士研究生招生专业方向：1.计算机应用技术，2.计算机软件与理论，3.计算机系统结构，4.模式识别与智能系统         专业型硕士研究生招生专业方向：计算机技术         研究生招生及录用条件：科研能力强，积极主动，勤奋好学，学习成绩优异，有较强的创新意识和团队协作精神。欢迎计算机、电子、控制、通信、仿真、物理、数学、生物医学等专业学生保研或报考。          指导本科生国家级创新实践项目情况：         指导我校本科生国家级创新实践项目5项（结题4项），是我校为数不多的指导多项国家级大学生创新实践项目的教师之一，在指导本科生科学研究和创新实践活动方面积累了丰富经验。              ');
/*!40000 ALTER TABLE `2014302580311_professor_info` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-11-19 17:15:29
